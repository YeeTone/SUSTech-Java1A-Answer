public class test {
    public static void main(String[] args) {
        GradeSystem g = new GradeSystem();
        Course c= new Course("JavaA");
        Student s = new Student("Zhangwh");
        g.addStudent(s);
        g.addCourse(c);
        g.addGrade(new Grade(c,s,99));
        System.out.println(c);
        System.out.println(s);
        System.out.println(g.getGradeList().get(0));
    }

}
